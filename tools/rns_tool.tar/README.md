# Tool di cognitiva
**Compilazione**

`gcc -o rns rns_sorgente.c  lib/libcogni.c -Ilib -lm`

**Uso**

`./rns -h`
